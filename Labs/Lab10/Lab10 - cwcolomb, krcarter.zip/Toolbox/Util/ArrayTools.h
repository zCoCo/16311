#ifndef _ARRAY_TOOLS_H
#define _ARRAY_TOOLS_H

  #define ARRAY_SIZE(arr) (sizeof(arr) / sizeof(float))
  #define ARRAY_SIZE_FLOAT(arr) (sizeof(arr) / sizeof(float))
  #define ARRAY_SIZE_INT(arr) (sizeof(arr) / sizeof(int))

#endif // _ARRAY_TOOLS_H
