#ifndef _ARRAY_TOOLS_H
#define _ARRAY_TOOLS_H

  #define ARRAY_SIZE(arr) (sizeof(arr) / sizeof(arr[0]))

#endif // _ARRAY_TOOLS_H
