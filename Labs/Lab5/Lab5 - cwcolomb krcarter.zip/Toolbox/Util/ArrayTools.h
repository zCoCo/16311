#ifndef _ARRAY_TOOLS_H
#define _ARRAY_TOOLS_H

  #define ARRAY_SIZE(arr) (sizeof(arr) / sizeof(float))

#endif // _ARRAY_TOOLS_H
