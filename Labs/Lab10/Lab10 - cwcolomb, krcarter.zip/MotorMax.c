
task main(){
  motor[motorA] = 100;
  motor[motorB] = 100;
  motor[motorC] = 100;
  while(1);
}
